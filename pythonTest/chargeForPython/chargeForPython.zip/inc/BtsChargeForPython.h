extern "C" {  
    BtsCDRmanager btsCDRmanager;  
    void display() {  
        obj.display();   
      }  
    void display_int() {  
        obj.display(2);   
      }  
}  