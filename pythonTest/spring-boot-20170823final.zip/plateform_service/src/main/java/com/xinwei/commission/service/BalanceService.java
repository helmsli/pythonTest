package com.xinwei.commission.service;

public interface BalanceService {
   
}
