/**
 * 
 */
package com.xinwei.commission.service.impl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.xinwei.commAccessDb.domain.BalanceTransRunning;
import com.xinwei.commission.domain.BalanceServiceContext;
import com.xinwei.lotteryDb.Const.UserBalanceApplyConst;
import com.xinwei.lotteryDb.domain.UserBalance;
import com.xinwei.lotteryDb.domain.UserBalanceApply;
import com.xinwei.lotteryDb.domain.UserBalanceApplyResult;
import com.xinwei.orderpost.domain.CommissionPresentInfo;

/**
 * @author helmsli
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class BalanceServiceImplTest extends BalanceServiceImpl{
    
	/**
	 * Test method for {@link com.xinwei.commission.service.impl.BalanceServiceImpl#pOneCommBalance(com.xinwei.commission.domain.BalanceServiceContext, com.xinwei.orderpost.domain.CommissionPresentInfo)}.
	 */
	@Test
	public void testPOneCommBalance() {
		BalanceServiceContext bServiceContext = new BalanceServiceContext(); 
		CommissionPresentInfo commissionPresentInfo = new CommissionPresentInfo();
		commissionPresentInfo.setAmt(100);
		commissionPresentInfo.setBizType(1);
		commissionPresentInfo.setExpireTime("20170911121314");
		commissionPresentInfo.setMsgInfo("msginfo");
		commissionPresentInfo.setOperType(1);
		commissionPresentInfo.setOrderID("orderid");
		commissionPresentInfo.setReason("reason");
		commissionPresentInfo.setReqTime("20170911121314");
		commissionPresentInfo.setReqTransId("00201708231735001234567");
		commissionPresentInfo.setSubsId(10000);
		
		this.pOneCommBalance(bServiceContext, commissionPresentInfo);
		
	}

	@Override
	protected boolean bTransHasDone(BalanceServiceContext bServiceContext, BalanceTransRunning balanceTransRunning) {
		// TODO Auto-generated method stub
		//return super.bTransHasDone(bServiceContext, balanceTransRunning);
		return false;
	}

	@Override
	protected UserBalanceApplyResult getBTransFromUserDb(UserBalanceApply userBalanceApply) {
		// TODO Auto-generated method stub
		//return super.getBTransFromUserDb(userBalanceApply);
		return createDefaultApplyResult();
	}

	@Override
	protected List<BalanceTransRunning> getBTransRunningFromDb(BalanceTransRunning balTransRunning) {
		// TODO Auto-generated method stub
		return new ArrayList();
	}

	@Override
	protected UserBalance getBalFromDb(BalanceServiceContext bServiceContext) {
		// TODO Auto-generated method stub
		//return super.getBalFromDb(bServiceContext);
		UserBalance userBalance = new UserBalance();
		userBalance.setAmount(123);
		userBalance.setBalance(1212);
		userBalance.setBalanceext("balanceext");
		userBalance.setExpiredata(Calendar.getInstance().getTime());
		userBalance.setOldBalanceext("oldbalancext");
		userBalance.setTelphonenum("1111");
		userBalance.setTransaction("002011122312131400000");
		userBalance.setUpdatetime(Calendar.getInstance().getTime());
		userBalance.setUserId(10000);
		return userBalance;
	}

	@Override
	protected UserBalance updateBTransRunningDb(BalanceServiceContext bServiceContext,
			UserBalanceApplyResult userBalanceApplyResult) {
		// TODO Auto-generated method stub
		//return super.updateBTransRunningDb(bServiceContext, userBalanceApplyResult);
		UserBalance userBalance = new UserBalance();
		userBalance.setAmount(123);
		userBalance.setBalance(1212);
		userBalance.setBalanceext("balanceext");
		userBalance.setExpiredata(Calendar.getInstance().getTime());
		userBalance.setOldBalanceext("oldbalancext");
		userBalance.setTelphonenum("1111");
		userBalance.setTransaction("002011122312131400000");
		userBalance.setUpdatetime(Calendar.getInstance().getTime());
		userBalance.setUserId(10000);
		return userBalance;
	}

	protected UserBalanceApplyResult createDefaultApplyResult()
	{
		UserBalanceApplyResult userBalanceApplyResult = new UserBalanceApplyResult();
		UserBalance userBalance = new UserBalance();
		userBalance.setAmount(123);
		userBalance.setBalance(1212);
		userBalance.setBalanceext("balanceext");
		userBalance.setExpiredata(Calendar.getInstance().getTime());
		userBalance.setOldBalanceext("oldbalancext");
		userBalance.setTelphonenum("1111");
		userBalance.setTransaction("002011122312131400000");
		userBalance.setUpdatetime(Calendar.getInstance().getTime());
		userBalance.setUserId(10000);
		userBalanceApplyResult.setResult(UserBalanceApplyConst.RESULT_SUCCESS);
		userBalanceApplyResult.setBalance(userBalance.getBalance());
		userBalanceApplyResult.setTransaction("002017082317401223333");
		userBalanceApplyResult.setExpiredata(userBalance.getExpiredata());
		userBalanceApplyResult.setUserId(userBalance.getUserId());
		return userBalanceApplyResult;
	}
	
	@Override
	protected UserBalanceApplyResult updateUserBalanceDb(UserBalance nowUserbalance,
			UserBalanceApply userBalanceApply) {
		// TODO Auto-generated method stub
				return createDefaultApplyResult();
		
	}

	@Override
	protected int updateBalDb(BalanceServiceContext bServiceContext, UserBalance nowUserbalance) {
		// TODO Auto-generated method stub
		return UserBalanceApplyConst.RESULT_SUCCESS;
	}
	

}
