﻿#-*- coding: UTF-8 -*- 
import pyExcelerator
sheets = pyExcelerator.parse_xls('/media/sf_vshare/python/pythonTest/excel/file/report.xls')
print sheets